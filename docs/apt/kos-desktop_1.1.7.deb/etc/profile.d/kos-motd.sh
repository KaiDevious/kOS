case $- in *i*)
  CONF=/etc/kos/config
  if [ -r "$CONF" ]; then . "$CONF"
    [ -n "$BASE_URL" ] && curl -4 -fsS --max-time 6 "$BASE_URL/message.txt?t=$(date +%s)" 2>/dev/null && echo
  fi ;;
esac
